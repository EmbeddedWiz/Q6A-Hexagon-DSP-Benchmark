
## HVX vector-add smoke test
- Date: 2026-10-09T18:03:16+00:00
- Target: Dragon Q6A, CDSP domain 3
- Compiler: Hexagon SDK 6.4.0.2, Hexagon Tools 19.0.04
- Target architecture: V68; HVX enabled, 128-byte vector length
- Operation: vector addition of 64 signed 16-bit lanes
- Validation: every output lane compared with scalar reference
- Result: PASS; FastRPC runner returned zero
- Execution log: `/home/radxa/Projects/Q6A-Hexagon-DSP-Benchmark/results/logs/20261009-180313-hvx-vector-add.log`

## 2026-10-09 — QuRT core cycle counter smoke test

- Built `dsp/fastrpc/qurt_cycles_smoke.c` with Hexagon SDK 6.4.0.2 / Hexagon Tools 19.0.04 for `-mv68`.
- Deployed and executed `qurt_cycles_smoke.so` on the Dragon Q6A CDSP through `run_main_on_hexagon`, FastRPC domain 3.
- Result: runner reported `Successfully called main() on Hexagon DSP and received return value of 0`.
- The test returns zero only if both consecutive readings from `qurt_get_core_pcycles()` increase across two short workload loops.
- Thermal readings: maximum reported zone temperature was 49.560 C before execution and 49.584 C after execution.
- Limitation: the runner output did not expose the printed numeric cycle deltas. Counter monotonicity is confirmed by the program's return condition; numeric timing values and measurement overhead are not yet validated.
- Safety: no sustained workload was run. Continue to pause at 82 C, abort at 84 C, and resume only below 78 C.
- Next step: establish a reliable way to export numeric timing results from the DSP, then benchmark scalar DSP and HVX workloads separately. Do not claim a performance gain until measured results are available.

## 2026-10-09 — CDSP scalar vs HVX cycle benchmark

- Target: Radxa Dragon Q6A, Qualcomm QCS6490, CDSP domain 3.
- Workload: 64 lanes of 16-bit accumulation, 5000 iterations.
- Scalar initial measurement: 2,336,683 core cycles.
- HVX 128B initial measurement: 35,062 core cycles.
- Initial ratio: 66.64x fewer core cycles for HVX.
- The runner prints nonzero DSP main return values as "Error"; positive values above are cycle counts, not test failures.
- Repeat-measurement console log: `results/logs/20261009-182253-hvx-cycle-repeat.log`.
- Repeat scalar cycles: 2335730, 2335745, 2337691, 2336218, 2335732; median 2335745, min/max 2335730/2337691.
- Repeat HVX 128B cycles: 35062, 35062, 35060, 35062, 35060; median 35062, min/max 35060/35062.
- Median ratio: 66.62x in favor of HVX.
- Status: five repeat runs completed; measurements are stable for this microbenchmark. Core cycles are not wall-clock latency.
- Caveat: these are core-cycle counts, not wall-clock latency. Do not treat the single initial sample as a final performance claim.


## Hexagon CDSP FOC FastRPC execution — 2026-10-12

- Artifact: `build/hexagon/foc_dsp.so` (ELF 32-bit Qualcomm DSP6, v68).
- Execution: `run_main_on_hexagon`, domain 3, unsigned protection domain.
- Workload per measurement: 5 × 16,384 FOC steps; best cycle count divided by 16,384.
- Cycle-count samples (cycles/step): 590, 590, 590, 590, 590.
- Minimum / median / maximum: 590 / 590 / 590 cycles per step.
- Measurement transport: `main()` returns cycles/step; runner labels nonzero values as errors. The reported numeric return is a measurement, not a zero-status success code.
- Scope: software benchmark on CDSP; no physical motor, PWM peripheral, or end-to-end real-time deadline validated.
