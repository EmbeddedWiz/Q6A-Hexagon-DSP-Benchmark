#pragma once

#include "motor_control.h"

#include <cstddef>
#include <cstdint>

namespace motor_control::fixed {

int16_t sin_q15(uint16_t angle);
int16_t cos_q15(uint16_t angle);

void compute(
    const Input& input,
    Output& output);

void compute_batch(
    const uint16_t* angles,
    Output* outputs,
    std::size_t count);

} // namespace motor_control::fixed
